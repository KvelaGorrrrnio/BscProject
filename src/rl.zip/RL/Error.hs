module Error where

-- =====
-- Errors
-- =====

type Error = String
